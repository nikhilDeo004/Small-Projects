const audio = document.getElementById("audioPlayer");

const elements = {
  play: document.getElementById("playBtn"),
  previous: document.getElementById("prevBtn"),
  next: document.getElementById("nextBtn"),
  progress: document.getElementById("progressBar"),
  volume: document.getElementById("volumeBar"),
  volumeValue: document.getElementById("volumeValue"),
  title: document.getElementById("songTitle"),
  artist: document.getElementById("songArtist"),
  currentTime: document.getElementById("currentTime"),
  duration: document.getElementById("duration"),
  playlist: document.getElementById("playlist"),
  songCount: document.getElementById("songCount"),
  search: document.getElementById("searchInput"),
  shuffle: document.getElementById("shuffleBtn"),
  repeat: document.getElementById("repeatBtn"),
  togglePlaylist: document.getElementById("togglePlaylist"),
  status: document.getElementById("statusMessage")
};

let currentIndex = 0;
let isShuffle = false;
let isRepeat = false;
let isSeeking = false;

function formatTime(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${String(secs).padStart(2, "0")}`;
}

function setStatus(message = "") {
  elements.status.textContent = message;
}

function loadSong(index) {
  if (!songs.length) return;

  currentIndex = (index + songs.length) % songs.length;
  const song = songs[currentIndex];

  audio.src = song.src;
  elements.title.textContent = song.title;
  elements.artist.textContent = song.artist || "Unknown Artist";
  elements.currentTime.textContent = "0:00";
  elements.duration.textContent = "0:00";
  elements.progress.value = 0;
  elements.progress.disabled = false;

  setStatus("");
  renderPlaylist();
  updateMediaSession();
}

async function playSong() {
  if (!songs.length) return;
  if (!audio.src) loadSong(currentIndex);

  try {
    await audio.play();
    setStatus("");
  } catch (error) {
    console.error("Audio playback failed:", error);
    setStatus("Unable to play this file. Check its filename and format.");
  }
}

function pauseSong() {
  audio.pause();
}

function nextSong() {
  if (!songs.length) return;

  let nextIndex;
  if (isShuffle && songs.length > 1) {
    do {
      nextIndex = Math.floor(Math.random() * songs.length);
    } while (nextIndex === currentIndex);
  } else {
    nextIndex = (currentIndex + 1) % songs.length;
  }

  loadSong(nextIndex);
  playSong();
}

function previousSong() {
  if (!songs.length) return;

  if (audio.currentTime > 3) {
    audio.currentTime = 0;
    return;
  }

  loadSong((currentIndex - 1 + songs.length) % songs.length);
  playSong();
}

function renderPlaylist(filteredSongs = getFilteredSongs()) {
  elements.playlist.replaceChildren();
  elements.songCount.textContent = filteredSongs.length;

  if (!filteredSongs.length) {
    const empty = document.createElement("p");
    empty.className = "empty-message";
    empty.textContent = songs.length ? "No songs found." : "Add songs in songs.js to get started.";
    elements.playlist.appendChild(empty);
    return;
  }

  filteredSongs.forEach((song) => {
    const actualIndex = songs.indexOf(song);
    const item = document.createElement("div");
    item.className = "song-item";
    item.setAttribute("role", "button");
    item.setAttribute("tabindex", "0");
    item.setAttribute("aria-label", `Play ${song.title}`);

    if (actualIndex === currentIndex) item.classList.add("active");

    const number = document.createElement("span");
    number.className = "song-number";
    number.textContent = actualIndex === currentIndex && !audio.paused
      ? "♪"
      : String(actualIndex + 1).padStart(2, "0");

    const details = document.createElement("div");
    details.className = "song-details";

    const title = document.createElement("h3");
    title.textContent = song.title;

    const artist = document.createElement("p");
    artist.textContent = song.artist || "Unknown Artist";
    details.append(title, artist);

    const indicator = document.createElement("span");
    indicator.className = "playing-indicator";
    indicator.textContent = actualIndex === currentIndex && !audio.paused ? "♫" : "";

    item.append(number, details, indicator);

    const selectSong = () => {
      loadSong(actualIndex);
      playSong();
    };

    item.addEventListener("click", selectSong);
    item.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectSong();
      }
    });

    elements.playlist.appendChild(item);
  });
}

function getFilteredSongs() {
  const query = elements.search.value.trim().toLowerCase();
  if (!query) return songs;

  return songs.filter((song) =>
    `${song.title} ${song.artist || ""}`.toLowerCase().includes(query)
  );
}

function updateMediaSession() {
  if (!("mediaSession" in navigator) || !("MediaMetadata" in window)) return;

  const song = songs[currentIndex];
  navigator.mediaSession.metadata = new MediaMetadata({
    title: song.title,
    artist: song.artist || "Unknown Artist",
    album: "MONO Music Player"
  });

  try {
    navigator.mediaSession.setActionHandler("play", playSong);
    navigator.mediaSession.setActionHandler("pause", pauseSong);
    navigator.mediaSession.setActionHandler("previoustrack", previousSong);
    navigator.mediaSession.setActionHandler("nexttrack", nextSong);
    navigator.mediaSession.setActionHandler("seekto", (details) => {
      if (Number.isFinite(details.seekTime)) audio.currentTime = details.seekTime;
    });
  } catch (error) {
    // Some browsers support only a subset of Media Session actions.
  }
}

elements.play.addEventListener("click", () => {
  if (audio.paused) playSong();
  else pauseSong();
});

elements.previous.addEventListener("click", previousSong);
elements.next.addEventListener("click", nextSong);

audio.addEventListener("play", () => {
  elements.play.textContent = "Ⅱ";
  elements.play.setAttribute("aria-label", "Pause");
  renderPlaylist();
});

audio.addEventListener("pause", () => {
  elements.play.textContent = "▶";
  elements.play.setAttribute("aria-label", "Play");
  renderPlaylist();
});

audio.addEventListener("loadedmetadata", () => {
  elements.duration.textContent = formatTime(audio.duration);
});

audio.addEventListener("timeupdate", () => {
  if (!isSeeking && Number.isFinite(audio.duration) && audio.duration > 0) {
    elements.progress.value = (audio.currentTime / audio.duration) * 1000;
  }
  elements.currentTime.textContent = formatTime(audio.currentTime);

  if ("mediaSession" in navigator && Number.isFinite(audio.duration) && audio.duration > 0) {
    try {
      navigator.mediaSession.setPositionState({
        duration: audio.duration,
        playbackRate: audio.playbackRate,
        position: audio.currentTime
      });
    } catch (error) {
      // Position state is optional browser support.
    }
  }
});

elements.progress.addEventListener("input", () => {
  isSeeking = true;
  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    const target = (Number(elements.progress.value) / 1000) * audio.duration;
    elements.currentTime.textContent = formatTime(target);
  }
});

elements.progress.addEventListener("change", () => {
  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    audio.currentTime = (Number(elements.progress.value) / 1000) * audio.duration;
  }
  isSeeking = false;
});

audio.addEventListener("ended", () => {
  if (isRepeat) {
    audio.currentTime = 0;
    playSong();
  } else if (isShuffle || currentIndex < songs.length - 1) {
    nextSong();
  } else {
    pauseSong();
    audio.currentTime = 0;
  }
});

audio.addEventListener("error", () => {
  setStatus("Could not load this audio file. Check the path in songs.js.");
});

elements.volume.addEventListener("input", () => {
  audio.volume = Number(elements.volume.value);
  elements.volumeValue.textContent = `${Math.round(audio.volume * 100)}%`;
});

elements.shuffle.addEventListener("click", () => {
  isShuffle = !isShuffle;
  elements.shuffle.classList.toggle("active", isShuffle);
  elements.shuffle.setAttribute("aria-pressed", String(isShuffle));
});

elements.repeat.addEventListener("click", () => {
  isRepeat = !isRepeat;
  elements.repeat.classList.toggle("active", isRepeat);
  elements.repeat.setAttribute("aria-pressed", String(isRepeat));
});

elements.search.addEventListener("input", () => renderPlaylist());

elements.togglePlaylist.addEventListener("click", () => {
  const willHide = elements.playlist.style.display !== "none";
  elements.playlist.style.display = willHide ? "none" : "flex";
  elements.togglePlaylist.textContent = willHide ? "SHOW LIST ↓" : "HIDE LIST ↑";
  elements.togglePlaylist.setAttribute("aria-expanded", String(!willHide));
});

// Initial setup
audio.volume = Number(elements.volume.value);

if (songs.length) {
  loadSong(0);
  elements.play.disabled = false;
  elements.previous.disabled = false;
  elements.next.disabled = false;
} else {
  elements.title.textContent = "No songs available";
  elements.artist.textContent = "Add audio files to songs.js";
  renderPlaylist([]);
  setStatus("Add your audio filenames to songs.js.");
}
