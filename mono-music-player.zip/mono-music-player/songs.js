/*
  Add your audio files to the /audios folder, then list them below.
  The src path is relative to index.html.
*/
const songs = [
  {
    title: "Song One",
    artist: "Unknown Artist",
    src: "audios/song1.mp3"
  },
  {
    title: "Song Two",
    artist: "Unknown Artist",
    src: "audios/song2.mp3"
  },
  {
    title: "Song Three",
    artist: "Unknown Artist",
    src: "audios/song3.mp3"
  },
  {
    title: "Song Four",
    artist: "Unknown Artist",
    src: "audios/song4.mp3"
  }
];
